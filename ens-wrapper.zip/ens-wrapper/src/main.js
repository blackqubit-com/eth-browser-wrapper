// Import necessary libraries
import { BrowserProvider, getDefaultProvider } from 'ethers';
import { create } from 'ipfs-http-client';
import { CID } from 'multiformats/cid';
import * as ipns from 'multiformats/src/ipns.js'; // For handling IPNS
import DOMPurify from 'dompurify';
import { Buffer } from 'buffer';
import process from 'process/browser';

// Polyfill for Buffer and process in browser environments
window.Buffer = Buffer;
window.process = process;

// Log script loading
console.log('Script loaded successfully.');

// Initialize IPFS client
const ipfs = create({ url: 'https://ipfs.io/api/v0' });
console.log('IPFS client initialized.');

// Initialize Ethereum provider
let provider;

if (window.ethereum) {
  console.log('MetaMask detected. Initializing BrowserProvider.');
  provider = new BrowserProvider(window.ethereum);
} else {
  console.log('MetaMask not detected. Using default provider.');
  provider = getDefaultProvider('mainnet');
}

/**
 * Function to load ENS content based on the ENS name.
 * @param {string} ensName - The ENS name (e.g., 'example.eth').
 */
async function loadENSContent(ensName) {
  console.log(`Attempting to load content for ENS name: ${ensName}`);
  try {
    // Request access to the user's Ethereum account if using MetaMask
    if (window.ethereum) {
      console.log('Requesting account access...');
      await provider.send('eth_requestAccounts', []);
      console.log('Account access granted.');
    }

    // Get the resolver for the ENS name
    console.log('Fetching resolver...');
    const resolver = await provider.getResolver(ensName);
    if (!resolver) {
      throw new Error('Resolver not found for ENS name');
    }
    console.log('Resolver obtained:', resolver);

    // Get the content hash
    console.log('Fetching content hash...');
    const contentHashRaw = await resolver.getContentHash();
    if (!contentHashRaw) {
      throw new Error('Content hash not set for ENS name');
    }
    console.log('Content hash obtained:', contentHashRaw);

    // Decode the content hash to get the IPFS CID or IPNS name
    console.log('Decoding content hash...');
    let fetchPath;

    if (contentHashRaw.startsWith('ipfs://')) {
      // Handle IPFS content hash
      console.log('Content hash is IPFS.');
      const cidStr = contentHashRaw.replace('ipfs://', '');
      const cid = CID.parse(cidStr);
      console.log('Parsed CID:', cid.toString());
      fetchPath = cid.toString(); // For IPFS, use the CID directly

    } else if (contentHashRaw.startsWith('ipns://')) {
      // Handle IPNS content hash
      console.log('Content hash is IPNS.');
      const ipnsName = contentHashRaw.replace('ipns://', '');
      console.log('Extracted IPNS name:', ipnsName);
      fetchPath = `/ipns/${ipnsName}`; // For IPNS, prepend with '/ipns/'

    } else if (contentHashRaw.startsWith('0x')) {
      // Handle hexadecimal content hash
      console.log('Content hash is hexadecimal.');
      const contentHashHex = contentHashRaw.slice(2); // Remove '0x'
      const cid = CID.parse(contentHashHex);
      console.log('Parsed CID from hex:', cid.toString());
      fetchPath = cid.toString();

    } else {
      throw new Error('Unsupported content hash format');
    }

    // Check if content is cached
    console.log('Checking sessionStorage for cached content...');
    const cachedContent = sessionStorage.getItem(ensName);
    if (cachedContent) {
      console.log('Cached content found. Displaying cached content.');
      document.getElementById('content').innerHTML = cachedContent;
      return;
    }

    // Fetch content from IPFS or IPNS
    console.log(`Fetching content from IPFS/IPNS at path: ${fetchPath}`);
    const content = await fetchIPFSContent(fetchPath);
    console.log('Content fetched:', content);

    // Sanitize content
    console.log('Sanitizing content...');
    const sanitizedContent = DOMPurify.sanitize(content);
    console.log('Sanitized content:', sanitizedContent);

    // Cache content in sessionStorage
    console.log('Caching content in sessionStorage...');
    sessionStorage.setItem(ensName, sanitizedContent);

    // Display content
    console.log('Displaying content on the page.');
    document.getElementById('content').innerHTML = sanitizedContent;

  } catch (error) {
    console.error('Error loading ENS content:', error);
    alert(`Error: ${error.message}`);
  }
}

/**
 * Function to fetch content from IPFS or IPNS.
 * @param {string} fetchPath - The IPFS CID or IPNS path.
 * @returns {Promise<string>} - The fetched content as a string.
 */
async function fetchIPFSContent(fetchPath) {
  console.log(`Fetching IPFS/IPNS content for path: ${fetchPath}`);
  let content = '';
  try {
    for await (const chunk of ipfs.cat(fetchPath)) {
      content += new TextDecoder().decode(chunk);
    }
    console.log('IPFS/IPNS content fetched:', content);
    return content;
  } catch (ipfsError) {
    console.error('Failed to fetch content from IPFS/IPNS:', ipfsError);
    throw new Error('Failed to fetch content from IPFS/IPNS');
  }
}

/**
 * Event listener for the load button.
 * Fetches and displays content based on the ENS input.
 */
document.addEventListener('DOMContentLoaded', () => {
  console.log('DOMContentLoaded event triggered.');
  const loadButton = document.getElementById('loadButton');
  if (loadButton) {
    loadButton.addEventListener('click', () => {
      console.log('Load button clicked.');
      const ensInput = document.getElementById('ensInput').value.trim();
      console.log('ENS input:', ensInput);
      debugger;
      if (ensInput.endsWith('.eth')) {
        loadENSContent(ensInput);
      } else {
        console.log('Invalid ENS domain entered.');
        alert('Please enter a valid .eth domain');
      }
    });
  } else {
    console.error('Load button not found in the DOM.');
  }
});
