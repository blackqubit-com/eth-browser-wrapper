# Getting Started

## How to use

Run the following commands in the root directory.

```bash
npm install
npm run build
npm run start
```
